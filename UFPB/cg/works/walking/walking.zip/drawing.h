#ifndef DRAWING_H_
#define DRAWING_H_

void draw_cube(float size);
void draw_pyramid(float base, float size);
void draw_rect(int size, int precision);

#endif